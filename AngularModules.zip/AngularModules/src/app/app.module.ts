import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { UserModule } from './user/user.module';
import { Comp1Component } from './comp1/comp1.component'; 
import { Mod1Module } from './mod1/mod1.module';

@NgModule({
  declarations: [AppComponent, Comp1Component],
  // Components, directives, controllers
  imports: [BrowserModule, UserModule, Mod1Module],
  // Modules
  bootstrap: [AppComponent],
  // Project Source file
})
export class AppModule {}
