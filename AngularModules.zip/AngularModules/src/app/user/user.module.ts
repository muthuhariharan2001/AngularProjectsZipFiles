import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserDetailComponent } from './user-detail/user-detail.component';

@NgModule({
  declarations: [UserDetailComponent], // components,
  imports: [CommonModule], // Import required Angular modules
  exports: [UserDetailComponent], // Export for use in other modules
})
export class UserModule {}
