import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'Angular Pipe Demo';
  currentDate = new Date(); 
  amount = 123456.789;
  // precision, 
  // Scale
  percentage = 0.1234;
  jsonData = { name: 'John', age: 30, city: 'New York' };

  ngOnInit(): void {
    // Update `currentDate` every second to keep the time live
    setInterval(() => {
      this.currentDate = new Date();
    }, 1000);
  }
}
