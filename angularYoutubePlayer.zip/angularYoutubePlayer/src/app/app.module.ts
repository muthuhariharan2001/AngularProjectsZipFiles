import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { YouTubePlayerModule } from '@angular/youtube-player';
import { CloudinaryModule } from '@cloudinary/ng';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, YouTubePlayerModule, CloudinaryModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}