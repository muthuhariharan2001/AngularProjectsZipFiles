import { Component } from '@angular/core';
import { Cloudinary, CloudinaryImage } from '@cloudinary/url-gen';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'AngularYoutubeCloudinary';
  videoId = 'as86Klk5qUE'; 
  img!: CloudinaryImage;

  constructor() {
    // Initialize Cloudinary
    const cld = new Cloudinary({ cloud: { cloudName: 'drgn3z6ty' } });
    this.img = cld.image('sample'); // Replace 'sample' with your image public ID
  }
}