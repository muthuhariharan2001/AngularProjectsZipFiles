import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

    getMessages() : string {
      return 'Hello, World!';
   }
}
